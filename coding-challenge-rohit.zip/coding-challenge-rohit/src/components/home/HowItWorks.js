import React from 'react';

class HowItWorks extends React.Component {

	constructor() {
		super();
		this.state = {
			versionContentResult: []
		}
	}

	componentDidMount() {
		fetch("https://uqnzta2geb.execute-api.us-east-1.amazonaws.com/default/FrontEndCodeChallenge")
			.then(res => res.json())
			.then(
				(result) => {
					result.sort(function(a,b){
						return Number(a.stepNumber) - Number(b.stepNumber);
					});
					result.forEach(entry => {
						entry.versionContent.sort(function(a,b){
							return new Date(b.effectiveDate) - new Date(a.effectiveDate);
						});
					});
					console.log(result);
					this.setState({
						versionContentResult: result
					})
				},
				(error) => {}
			);
	}

	render() {
		return (
			<div className="how_it_works">
				<h5 className='heading'>How It Works</h5>
				<div className='row'>
					<div className='offset-md-2 col-md-8 offset-sm-1 col-sm-10 xs-12'>
						<div className='row'>
							{
								this.state.versionContentResult.map((entry, index) => (
									<div className='col-md-3 col-sm-6 xs-12 version_content' key={index}>
										<h2 className='step_number'>{Number(entry.stepNumber) < 10 ? '0'+entry.stepNumber : entry.stepNumber}</h2>
										<h6 className='step_title'>{entry.versionContent[0].title}</h6>
										<p className='step_description'>{entry.versionContent[0].body}</p>
									</div>
								))
							}
						</div>
					</div>
				</div>
			</div>
		);
	}
}

export default HowItWorks;