import React from 'react';
import { Button } from 'react-bootstrap';
import HowItWorks from './HowItWorks';
import './home.scss';

const Home = () => (
	<div className="body">
		<div className='introduction'>
			<div className='introduction_text'>
				<div className='row'>
					<div className='offset-md-2 offset-1'>
						<h5>New Games & Accessories</h5>
						<h1>Monthly packages.<br />Excitement delivered daily.</h1>
						<p>
							What's the best way to shop for the latest video games <br/>
							and peripherals? How about never shopping at all?<br/>
							You'll get new stuff on your doorstep - every month.
						</p>
						<Button variant="primary">GET STARTED</Button>
					</div>
				</div>
			</div>
		</div>
		<HowItWorks />
	</div>
);

export default Home;