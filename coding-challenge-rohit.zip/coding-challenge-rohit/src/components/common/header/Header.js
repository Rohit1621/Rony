import React from 'react';
import './header.scss';

const Header = () => (
	<header className="app-header">
		<div className='row'>
			<div className='offset-md-2 offset-1'>
				ENDLESS
			</div>
		</div>
	</header>
);

export default Header;