import React from 'react';
import Header from './components/common/header/Header';
import Home from './components/home/Home';
import './App.scss';

function App() {
  return (
    <div className="container-fluid app">
      <Header />
      <Home />
    </div>
  );
}

export default App;
